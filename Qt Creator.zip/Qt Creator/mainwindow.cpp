#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFile>
#include <QMessageBox>
#include <QTextStream>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

//Switch to Coordinates page
void MainWindow::on_pushButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(1); //Accept T&C move to next page
}

//Switch to T&C Page
void MainWindow::on_pushButton_3_clicked()
{
    ui->stackedWidget->setCurrentIndex(0); //Accept T&C move to next page
}

//Sent info to interface/Sent info to drone
void MainWindow::on_pushButton_2_clicked()
{

if(ui->lineEditZ_1->text().toInt() < 400){
    if(ui->lineEditZ_2->text().toInt() < 400){
        if(ui->lineEditZ_3->text().toInt() < 400){

            // setting all coordinates to UInt32
            quint32 x1 = ui->lineEditX_1->text().toUInt();
            quint32 y1 = ui->lineEditY_1->text().toUInt();
            quint32 z1 = ui->lineEditZ_1->text().toUInt();

            quint32 x2 = ui->lineEditX_2->text().toUInt();
            quint32 y2 = ui->lineEditY_2->text().toUInt();
            quint32 z2 = ui->lineEditZ_2->text().toUInt();

            quint32 x3 = ui->lineEditX_3->text().toUInt();
            quint32 y3 = ui->lineEditY_3->text().toUInt();
            quint32 z3 = ui->lineEditZ_3->text().toUInt();

    QMessageBox::information(this, "             CONFIRMATION NOTICE!", "Coordinates 1, 2 and 3 recieved!", "ok"); // confirmation nottice

          QFile file2("C:/Users/Samael Crimsonblood/Desktop/Testing UI/SentToDrone.Hon"); // Coordinates sent to the drone
                if(file2.open(QIODevice::WriteOnly | QIODevice::Text))
                {

                    QTextStream stream(&file2);

                    stream << x1 << '\t' << y1 << '\t' << z1 << '\n'
                           << x2 << '\t' << y2 << '\t' << z2 << '\n'
                           << x3 << '\t' << y3 << '\t' << z3 << '\n'
                           << "" <<'\n';

                    file2.close();
                    qDebug() << "Sent coordinates to Drone";
                }

                QFile file("C:/Users/Samael Crimsonblood/Desktop/Testing UI/Log.txt"); // Drone coordinate log of most recent flight mission
                      if(file.open(QIODevice::WriteOnly | QIODevice::Text))
                      {

                          QTextStream stream(&file);

                          stream << "Arrived to first coordinates: " << x1 << "  " << y1 << "  " << z1 << "" <<'\n'
                                 << "Arrived to seccond coordinates: " << x2 << "  " << y2 << "  " << z2 << "" <<'\n'
                                 << "Arrived to third coordinates: " << x3 << "  " << y3 << "  " << z3 << "" <<'\n'
                                 << "" <<'\n';

                          file.close();
                          qDebug() << "Recived Coordinates";
                      }

}
        else
        {
                    QMessageBox::information(this, "Error NOTICE!", "Please change value of Z coordinate 3 to less than 400", "ok");
        }
}
    else
    {
                QMessageBox::information(this, "Error NOTICE!", "Please change value of Z coordinate 2 to less than 400", "ok");
    }
}
else
{
      QMessageBox::information(this, "Error NOTICE!", "Please change value of Z coordinate 1 to less than 400", "ok");
}
}

